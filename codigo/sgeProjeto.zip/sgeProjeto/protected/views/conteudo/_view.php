<?php
/* @var $this ConteudoController */
/* @var $data Conteudo */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idConteudo')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idConteudo), array('view', 'id'=>$data->idConteudo)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('assunto')); ?>:</b>
	<?php echo CHtml::encode($data->assunto); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('data')); ?>:</b>
	<?php echo CHtml::encode($data->data); ?>
	<br />


</div>