<?php
/* @var $this ConteudoController */
/* @var $model Conteudo */

$this->breadcrumbs=array(
	'Conteudos'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Conteudo', 'url'=>array('index')),
	array('label'=>'Manage Conteudo', 'url'=>array('admin')),
);
?>

<h1>Create Conteudo</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>