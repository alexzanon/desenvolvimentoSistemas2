<?php
/* @var $this ConteudoController */
/* @var $model Conteudo */

$this->breadcrumbs=array(
	'Conteudos'=>array('index'),
	$model->idConteudo=>array('view','id'=>$model->idConteudo),
	'Update',
);

$this->menu=array(
	array('label'=>'List Conteudo', 'url'=>array('index')),
	array('label'=>'Create Conteudo', 'url'=>array('create')),
	array('label'=>'View Conteudo', 'url'=>array('view', 'id'=>$model->idConteudo)),
	array('label'=>'Manage Conteudo', 'url'=>array('admin')),
);
?>

<h1>Update Conteudo <?php echo $model->idConteudo; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>