<?php
/* @var $this ConteudoController */
/* @var $model Conteudo */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'idConteudo'); ?>
		<?php echo $form->textField($model,'idConteudo'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'assunto'); ?>
		<?php echo $form->textField($model,'assunto',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'data'); ?>
		<?php echo $form->textField($model,'data'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->