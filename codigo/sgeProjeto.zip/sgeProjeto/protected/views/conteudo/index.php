<?php
/* @var $this ConteudoController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Conteudos',
);

$this->menu=array(
	array('label'=>'Create Conteudo', 'url'=>array('create')),
	array('label'=>'Manage Conteudo', 'url'=>array('admin')),
);
?>

<h1>Conteudos</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
