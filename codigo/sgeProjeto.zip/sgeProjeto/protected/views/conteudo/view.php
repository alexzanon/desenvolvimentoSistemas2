<?php
/* @var $this ConteudoController */
/* @var $model Conteudo */

$this->breadcrumbs=array(
	'Conteudos'=>array('index'),
	$model->idConteudo,
);

$this->menu=array(
	array('label'=>'List Conteudo', 'url'=>array('index')),
	array('label'=>'Create Conteudo', 'url'=>array('create')),
	array('label'=>'Update Conteudo', 'url'=>array('update', 'id'=>$model->idConteudo)),
	array('label'=>'Delete Conteudo', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->idConteudo),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Conteudo', 'url'=>array('admin')),
);
?>

<h1>View Conteudo #<?php echo $model->idConteudo; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'idConteudo',
		'assunto',
		'data',
	),
)); ?>
