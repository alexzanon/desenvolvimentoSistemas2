<?php
/* @var $this AlunoController */
/* @var $data Aluno */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('matricula')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->matricula), array('view', 'id'=>$data->matricula)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nomeAluno')); ?>:</b>
	<?php echo CHtml::encode($data->nomeAluno); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('cpf')); ?>:</b>
	<?php echo CHtml::encode($data->cpf); ?>
	<br />


</div>