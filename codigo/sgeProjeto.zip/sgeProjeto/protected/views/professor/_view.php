<?php
/* @var $this ProfessorController */
/* @var $data Professor */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idProfessor')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idProfessor), array('view', 'id'=>$data->idProfessor)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nomeProfessor')); ?>:</b>
	<?php echo CHtml::encode($data->nomeProfessor); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('cpf')); ?>:</b>
	<?php echo CHtml::encode($data->cpf); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('senha')); ?>:</b>
	<?php echo CHtml::encode($data->senha); ?>
	<br />


</div>