<?php
/* @var $this FrequenciaController */
/* @var $data Frequencia */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idFrequencia')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idFrequencia), array('view', 'id'=>$data->idFrequencia)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('presenca')); ?>:</b>
	<?php echo CHtml::encode($data->presenca); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('data')); ?>:</b>
	<?php echo CHtml::encode($data->data); ?>
	<br />


</div>