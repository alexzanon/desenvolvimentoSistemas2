<?php
/* @var $this FrequenciaController */
/* @var $model Frequencia */

$this->breadcrumbs=array(
	'Frequencias'=>array('index'),
	$model->idFrequencia=>array('view','id'=>$model->idFrequencia),
	'Update',
);

$this->menu=array(
	array('label'=>'List Frequencia', 'url'=>array('index')),
	array('label'=>'Create Frequencia', 'url'=>array('create')),
	array('label'=>'View Frequencia', 'url'=>array('view', 'id'=>$model->idFrequencia)),
	array('label'=>'Manage Frequencia', 'url'=>array('admin')),
);
?>

<h1>Update Frequencia <?php echo $model->idFrequencia; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>