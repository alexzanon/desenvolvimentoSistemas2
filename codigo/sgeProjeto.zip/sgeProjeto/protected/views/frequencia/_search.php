<?php
/* @var $this FrequenciaController */
/* @var $model Frequencia */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'idFrequencia'); ?>
		<?php echo $form->textField($model,'idFrequencia'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'presenca'); ?>
		<?php echo $form->textField($model,'presenca'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'data'); ?>
		<?php echo $form->textField($model,'data'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->