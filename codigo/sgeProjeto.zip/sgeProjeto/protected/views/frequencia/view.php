<?php
/* @var $this FrequenciaController */
/* @var $model Frequencia */

$this->breadcrumbs=array(
	'Frequencias'=>array('index'),
	$model->idFrequencia,
);

$this->menu=array(
	array('label'=>'List Frequencia', 'url'=>array('index')),
	array('label'=>'Create Frequencia', 'url'=>array('create')),
	array('label'=>'Update Frequencia', 'url'=>array('update', 'id'=>$model->idFrequencia)),
	array('label'=>'Delete Frequencia', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->idFrequencia),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Frequencia', 'url'=>array('admin')),
);
?>

<h1>View Frequencia #<?php echo $model->idFrequencia; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'idFrequencia',
		'presenca',
		'data',
	),
)); ?>
