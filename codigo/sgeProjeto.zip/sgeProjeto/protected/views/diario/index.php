<?php
/* @var $this DiarioController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Diarios',
);

$this->menu=array(
	array('label'=>'Create Diario', 'url'=>array('create')),
	array('label'=>'Manage Diario', 'url'=>array('admin')),
);
?>

<h1>Diarios</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
