<?php
/* @var $this DiarioController */
/* @var $model Diario */

$this->breadcrumbs=array(
	'Diarios'=>array('index'),
	$model->idDiario,
);

$this->menu=array(
	array('label'=>'List Diario', 'url'=>array('index')),
	array('label'=>'Create Diario', 'url'=>array('create')),
	array('label'=>'Update Diario', 'url'=>array('update', 'id'=>$model->idDiario)),
	array('label'=>'Delete Diario', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->idDiario),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Diario', 'url'=>array('admin')),
);
?>

<h1>View Diario #<?php echo $model->idDiario; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'idDiario',
		'nomeDiario',
		'codFrequencia',
		'codConteudo',
		'Aluno_matricula',
		'Professor_idProfessor',
	),
)); ?>
