<?php
/* @var $this DiarioController */
/* @var $model Diario */

$this->breadcrumbs=array(
	'Diarios'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Diario', 'url'=>array('index')),
	array('label'=>'Manage Diario', 'url'=>array('admin')),
);
?>

<h1>Create Diario</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>