<?php
/* @var $this DiarioController */
/* @var $model Diario */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'diario-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'nomeDiario'); ?>
		<?php echo $form->textField($model,'nomeDiario',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'nomeDiario'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'codFrequencia'); ?>
		<?php echo $form->textField($model,'codFrequencia'); ?>
		<?php echo $form->error($model,'codFrequencia'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'codConteudo'); ?>
		<?php echo $form->textField($model,'codConteudo'); ?>
		<?php echo $form->error($model,'codConteudo'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Aluno_matricula'); ?>
		<?php echo $form->textField($model,'Aluno_matricula'); ?>
		<?php echo $form->error($model,'Aluno_matricula'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Professor_idProfessor'); ?>
		<?php echo $form->textField($model,'Professor_idProfessor'); ?>
		<?php echo $form->error($model,'Professor_idProfessor'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->