<?php
/* @var $this DiarioController */
/* @var $model Diario */

$this->breadcrumbs=array(
	'Diarios'=>array('index'),
	$model->idDiario=>array('view','id'=>$model->idDiario),
	'Update',
);

$this->menu=array(
	array('label'=>'List Diario', 'url'=>array('index')),
	array('label'=>'Create Diario', 'url'=>array('create')),
	array('label'=>'View Diario', 'url'=>array('view', 'id'=>$model->idDiario)),
	array('label'=>'Manage Diario', 'url'=>array('admin')),
);
?>

<h1>Update Diario <?php echo $model->idDiario; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>