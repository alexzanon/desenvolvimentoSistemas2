<?php
/* @var $this DiarioController */
/* @var $model Diario */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'idDiario'); ?>
		<?php echo $form->textField($model,'idDiario'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nomeDiario'); ?>
		<?php echo $form->textField($model,'nomeDiario',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'codFrequencia'); ?>
		<?php echo $form->textField($model,'codFrequencia'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'codConteudo'); ?>
		<?php echo $form->textField($model,'codConteudo'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Aluno_matricula'); ?>
		<?php echo $form->textField($model,'Aluno_matricula'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Professor_idProfessor'); ?>
		<?php echo $form->textField($model,'Professor_idProfessor'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->