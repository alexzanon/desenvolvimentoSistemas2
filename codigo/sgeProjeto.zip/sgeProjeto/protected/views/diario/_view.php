<?php
/* @var $this DiarioController */
/* @var $data Diario */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idDiario')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idDiario), array('view', 'id'=>$data->idDiario)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nomeDiario')); ?>:</b>
	<?php echo CHtml::encode($data->nomeDiario); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('codFrequencia')); ?>:</b>
	<?php echo CHtml::encode($data->codFrequencia); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('codConteudo')); ?>:</b>
	<?php echo CHtml::encode($data->codConteudo); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Aluno_matricula')); ?>:</b>
	<?php echo CHtml::encode($data->Aluno_matricula); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Professor_idProfessor')); ?>:</b>
	<?php echo CHtml::encode($data->Professor_idProfessor); ?>
	<br />


</div>