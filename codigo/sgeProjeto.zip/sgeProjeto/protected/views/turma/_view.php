<?php
/* @var $this TurmaController */
/* @var $data Turma */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idTurma')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idTurma), array('view', 'id'=>$data->idTurma)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nomeTurma')); ?>:</b>
	<?php echo CHtml::encode($data->nomeTurma); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('curso')); ?>:</b>
	<?php echo CHtml::encode($data->curso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Diario_idDiario')); ?>:</b>
	<?php echo CHtml::encode($data->Diario_idDiario); ?>
	<br />


</div>